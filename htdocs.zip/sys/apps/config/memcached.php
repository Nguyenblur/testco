<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config = array(
	'default' => array(
		'hostname' => Cache_Mem_Ip,
		'port'     => Cache_Mem_Port,
		'weight'   => '1',
	),
);